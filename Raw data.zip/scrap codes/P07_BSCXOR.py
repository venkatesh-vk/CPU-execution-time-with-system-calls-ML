# Given two logic values p and q (0 or 1) please compute p XOR q.
#
# Example
#
# Input:
# 1 1
#
# Output:
# 0

a, b = map(int, input().split())
if a != b:
    print(1)
else:
    print(0)
