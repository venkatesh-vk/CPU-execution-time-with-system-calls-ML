# Author: OMKAR PATHAK
# This program prints the entered message

def justPrint(text):
    '''This function prints the text passed as argument to this function'''
    print(text)

if __name__ == '__main__':
    justPrint('Hello')
