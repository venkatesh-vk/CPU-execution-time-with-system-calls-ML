'''
import numpy as n
k,m= map(int, input().split())
a=n.array([input().split() for i in range(k)],int)
print(n.mean(a,axis=1))
print(n.var(a,axis=0))
print("{:.11f}".format(n.std(a)))
'''
from itertools import permutations as p
def min_permutation(n):
    b=[]
    d=str(n)
    f=0
    if (n<0):
        n=str(n)
        d=n[1:]
        f=1
    a=[int(x) for x in d]
    c=list(p(a))
    for i in c:
        if i[0]==0:
            continue
        t=[str(x) for x in i]
        t=''.join(t)
        b.append(t)
    
    if f==0:
        return min(b)
    else:
        q='-'+str(min(b))
        return int(q)
print(min_permutation(-20))
