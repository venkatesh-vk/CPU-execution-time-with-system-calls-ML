n="""
URC NCC GP HQ
MADURAI

DAILY REPORT AS ON {}

DATE  {}
*********************
OPENING STOCK 
LIQ  {}
GRO  {}
***********************
DAILY SALE   {}

LIQ  {}
GRO  {}
***********************
MONTHLY SALE 
TOTAL {}
********************
CLOSING STOCK 

LIQ  {}
GRO  {}
***********************
DIGITAL TRANSACTION  {} %
CASH TRANSACTION   {} %

*********************
BANK BALANCE 

QD A/C  IOB
Rs {}
URC A/C {}
***********************
BRONZE CARD  {}
LIQ  {}
GRO  {}
**********************
WARM REGARDS

UNIT RUN CANTEEN 

GR HQ
"""

#print(len(a))

n=n.format('13.12.22','12.12.22','587271.56','7265824.29','12.12.22','43,835.00','2,58,559.00','12,67,901.00','547422.49','7018286.91','100','0','13,11,720.00','62,56,530.14','12.12.22','0','0')

print(n)