t = int(input())
while t:
    n = input()
    print(int(n[::-1]))
    t -= 1
