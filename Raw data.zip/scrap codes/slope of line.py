a=[0,0,0,0,0," "]
print("Enter the values of x1,x2,y1,y2")
for i in range(4):
    a[i]=int(input())
a[4]=(a[3]-a[2])/(a[1]-a[0])

print("Horizontal" if a[4]>=0 else "vertical")
