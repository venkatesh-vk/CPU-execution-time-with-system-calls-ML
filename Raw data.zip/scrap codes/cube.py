'''
def sum3cubes(n):
    t=n**(1/3)
    t=int(t)
    i=1
    print(t)
    for i in range(1,t+1):
        s=(i**3)*3
        if s==t:
            return True
        else:
            s=((i**3)+(i**3)+((i+1)**3))
            if s==t:
                return True
            else:
                s=(((i)**3)+((i+1)**3)+((i+2)**3))
                if s==t:
                    return True
                else:
                    return False
'''
def sum3cubes(n):
    a=[1,1,1]
    t=int(n**(1/3))
    for i in range(1,t+1):
        s=[(x**3) for x in a]
        if s==t:
            return True
        else:
            a[i]+=1
    else:
        return False

print(sum3cubes(10))
