while True:
    x = int(input())
    if x==42:
        break
    print (x)